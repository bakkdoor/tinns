-- phpMyAdmin SQL Dump
-- version 2.6.3-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Erstellungszeit: 22. Februar 2006 um 00:12
-- Server Version: 4.1.10
-- PHP-Version: 4.3.10
-- 
-- Datenbank: `infoserver`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `accounts`
-- 

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `a_id` int(10) unsigned NOT NULL auto_increment,
  `a_username` varchar(45) NOT NULL default '',
  `a_password` varchar(45) NOT NULL default '',
  `a_priv` int(10) unsigned default '0',
  `a_status` int(10) unsigned default '0',
  `a_bandate` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`a_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `accounts`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `server_list`
-- 

DROP TABLE IF EXISTS `server_list`;
CREATE TABLE IF NOT EXISTS `server_list` (
  `s_id` int(10) unsigned NOT NULL auto_increment,
  `s_name` varchar(15) NOT NULL default 'NC server',
  `s_addr` varchar(15) NOT NULL default '127.0.0.1',
  `s_port` int(10) unsigned NOT NULL default '12000',
  `s_players` int(10) unsigned NOT NULL default '0',
  `s_lastupdate` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Daten für Tabelle `server_list`
-- 

INSERT INTO `server_list` (`s_id`, `s_name`, `s_addr`, `s_port`, `s_players`, `s_lastupdate`) VALUES (1, 'LAN', '192.168.0.103', 12001, 0, '0000-00-00 00:00:00');
INSERT INTO `server_list` (`s_id`, `s_name`, `s_addr`, `s_port`, `s_players`, `s_lastupdate`) VALUES (3, 'WAN', '63.135.27.250', 12001, 0, '0000-00-00 00:00:00');
