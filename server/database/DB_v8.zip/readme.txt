This .zip file contains an UPDATE and a FULL DUMP
for both InfoDB and GameDB.
If you want to keep your data and just upgrade the structure,
use
	patch_gamedb_rev7_to_rev8.sql

to get up to date. However, it is recommended to use the FULL files
to build a new database.
There is some data already in GameDB, mostly NPC spawns and Outpost IDs that are
required.

See changes.txt for information about what has changed from DB7 to DB8