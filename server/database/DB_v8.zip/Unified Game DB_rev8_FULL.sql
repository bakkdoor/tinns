/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`gameserver` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_general_ci */;

USE `gameserver`;

/*Table structure for table `apartments` */

DROP TABLE IF EXISTS `apartments`;

CREATE TABLE `apartments` (
  `apt_id` int(10) unsigned NOT NULL auto_increment,
  `apt_location` int(10) unsigned NOT NULL default '0',
  `apt_type` int(10) unsigned NOT NULL default '0',
  `apt_password` varchar(45) NOT NULL default '',
  `apt_owner` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`apt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `buddy_list` */

DROP TABLE IF EXISTS `buddy_list`;

CREATE TABLE `buddy_list` (
  `bud_id` int(10) NOT NULL auto_increment,
  `bud_charid` int(10) NOT NULL default '0',
  `bud_buddyid` mediumint(10) NOT NULL default '0',
  PRIMARY KEY  (`bud_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `bug_report` */

DROP TABLE IF EXISTS `bug_report`;

CREATE TABLE `bug_report` (
  `br_id` int(10) unsigned NOT NULL auto_increment,
  `br_type` int(10) unsigned NOT NULL default '0' COMMENT 'Type',
  `br_desc` varchar(1024) NOT NULL COMMENT 'Description',
  `br_fromid` int(10) unsigned NOT NULL default '0' COMMENT 'Char ID of reporter',
  `br_location` int(10) unsigned NOT NULL default '0' COMMENT 'Location where problem occured',
  `br_status` int(10) unsigned NOT NULL default '0' COMMENT 'Status',
  `br_datetime` varchar(45) NOT NULL COMMENT 'Date/Time',
  `br_supid` int(10) unsigned NOT NULL default '0' COMMENT 'Supporter ID',
  PRIMARY KEY  (`br_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `characters` */

DROP TABLE IF EXISTS `characters`;

CREATE TABLE `characters` (
  `c_id` int(10) unsigned NOT NULL auto_increment,
  `c_name` varchar(45) default '',
  `c_str_lvl` int(10) unsigned default '0',
  `c_str_pts` int(10) unsigned default '0',
  `c_int_lvl` int(10) unsigned default '0',
  `c_int_pts` int(10) unsigned default '0',
  `c_dex_lvl` int(10) unsigned default '0',
  `c_dex_pts` int(10) unsigned default '0',
  `c_con_lvl` int(10) unsigned default '0',
  `c_con_pts` int(10) unsigned default '0',
  `c_psi_lvl` int(10) unsigned default '0',
  `c_psi_pts` int(10) unsigned default '0',
  `a_id` int(10) unsigned default '0',
  `c_class` int(10) unsigned default '0',
  `c_profession` int(10) unsigned default '0',
  `c_sex` int(10) unsigned default '0',
  `c_location` int(10) unsigned default '1',
  `c_mc` int(10) unsigned default '0',
  `c_hc` int(10) unsigned default '0',
  `c_tra` int(10) unsigned default '0',
  `c_pc` int(10) unsigned default '0',
  `c_rc` int(10) unsigned default '0',
  `c_tc` int(10) unsigned default '0',
  `c_vhc` int(10) unsigned default '0',
  `c_agl` int(10) unsigned default '0',
  `c_rep` int(10) unsigned default '0',
  `c_rec` int(10) unsigned default '0',
  `c_rcl` int(10) unsigned default '0',
  `c_atl` int(10) unsigned default '0',
  `c_end` int(10) unsigned default '0',
  `c_for` int(10) unsigned default '0',
  `c_fir` int(10) unsigned default '0',
  `c_enr` int(10) unsigned default '0',
  `c_xrr` int(10) unsigned default '0',
  `c_por` int(10) unsigned default '0',
  `c_htl` int(10) unsigned default '0',
  `c_hck` int(10) unsigned default '0',
  `c_brt` int(10) unsigned default '0',
  `c_psu` int(10) unsigned default '0',
  `c_wep` int(10) unsigned default '0',
  `c_cst` int(10) unsigned default '0',
  `c_res` int(10) unsigned default '0',
  `c_imp` int(10) unsigned default '0',
  `c_ppu` int(10) unsigned default '0',
  `c_apu` int(10) unsigned default '0',
  `c_mst` int(10) unsigned default '0',
  `c_ppw` int(10) unsigned default '0',
  `c_psr` int(10) unsigned default '0',
  `c_wpw` int(10) unsigned default '0',
  `c_apt` int(10) unsigned default '0',
  `c_cash` int(10) unsigned default '0',
  `c_head` int(10) unsigned default '0',
  `c_torso` int(10) unsigned default '0',
  `c_legs` int(10) unsigned default '0',
  `c_str_xp` float default '0',
  `c_int_xp` float default '0',
  `c_dex_xp` float default '0',
  `c_psi_xp` float default '0',
  `c_con_xp` float default '0',
  `c_pos_x` float NOT NULL default '0',
  `c_pos_y` float NOT NULL default '0',
  `c_pos_z` float NOT NULL default '0',
  `c_angle_ud` float NOT NULL default '0',
  `c_angle_lr` float NOT NULL default '0',
  `c_faction` int(10) unsigned NOT NULL default '0',
  `c_slot` smallint(5) unsigned NOT NULL default '0',
  `c_online` int(1) default '0',
  `c_clan` int(10) default '0',
  `c_soullight` int(3) default '10',
  PRIMARY KEY  (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Table structure for table `clanlevels` */

DROP TABLE IF EXISTS `clanlevels`;

CREATE TABLE `clanlevels` (
  `cll_id` int(10) NOT NULL auto_increment,
  `cll_clanid` int(10) default '0',
  `cll_level` int(2) default '0',
  `cll_desc` char(255) collate latin1_general_ci default NULL,
  `cll_charid` int(10) default NULL,
  PRIMARY KEY  (`cll_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `clans` */

DROP TABLE IF EXISTS `clans`;

CREATE TABLE `clans` (
  `cl_id` int(10) unsigned NOT NULL auto_increment,
  `cl_shortdesc` char(16) collate latin1_general_ci default NULL,
  `cl_name` char(64) collate latin1_general_ci default NULL,
  `cl_faction` int(2) default NULL,
  `cl_description` varchar(256) collate latin1_general_ci default NULL,
  `cl_leader` int(10) default '0',
  `cl_money` int(10) default '0',
  `cl_minsympathy` int(3) default '70',
  `cl_appid` int(10) default '0',
  `cl_representative` int(10) default '0',
  PRIMARY KEY  (`cl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1002 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `clanwars` */

DROP TABLE IF EXISTS `clanwars`;

CREATE TABLE `clanwars` (
  `cw_id` int(10) NOT NULL auto_increment,
  `cw_initclan` int(10) default '0',
  `cw_enemyclan` int(10) default '0',
  `cw_starttime` varchar(45) collate latin1_general_ci default '',
  `cw_status` int(2) default '0',
  `cw_statement_initiator` varchar(512) collate latin1_general_ci default '',
  `cw_statement_enemy` varchar(512) collate latin1_general_ci default '',
  PRIMARY KEY  (`cw_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `contacts` */

DROP TABLE IF EXISTS `contacts`;

CREATE TABLE `contacts` (
  `c_id` int(10) unsigned NOT NULL auto_increment,
  `c_listid` int(10) unsigned NOT NULL default '0' COMMENT 'Who''s list?',
  `c_conid` int(10) unsigned NOT NULL default '0' COMMENT 'Char ID of person on list',
  `c_type` int(10) unsigned NOT NULL default '0' COMMENT '1=Personal, 2=Business, 3=Allied',
  `c_desc` varchar(256) NOT NULL,
  PRIMARY KEY  (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `datacubes` */

DROP TABLE IF EXISTS `datacubes`;

CREATE TABLE `datacubes` (
  `cb_id` int(10) NOT NULL auto_increment,
  `cb_securitycode` char(30) collate latin1_general_ci default '',
  `cb_inscription` tinytext collate latin1_general_ci,
  PRIMARY KEY  (`cb_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `emails` */

DROP TABLE IF EXISTS `emails`;

CREATE TABLE `emails` (
  `e_id` int(10) unsigned NOT NULL auto_increment,
  `e_subject` varchar(128) NOT NULL default '',
  `e_fromid` int(10) unsigned NOT NULL default '0',
  `e_datetime` varchar(45) NOT NULL default '0',
  `e_toid` int(10) unsigned NOT NULL default '0',
  `e_body` varchar(512) NOT NULL,
  `e_new` tinyint(1) NOT NULL default '1',
  `e_replied` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`e_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Table structure for table `forum_posts` */

DROP TABLE IF EXISTS `forum_posts`;

CREATE TABLE `forum_posts` (
  `fp_id` int(10) unsigned NOT NULL auto_increment,
  `fp_name` varchar(45) NOT NULL default '',
  `fp_fromid` int(10) unsigned NOT NULL default '0',
  `fp_content` varchar(2048) NOT NULL default '',
  `fp_datetime` varchar(45) NOT NULL default '',
  `fp_replyid` int(10) unsigned NOT NULL default '0',
  `fp_forumid` int(10) unsigned NOT NULL default '0',
  `fp_factionid` int(2) default '0',
  `fp_clanid` int(10) default '0',
  PRIMARY KEY  (`fp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `forums` */

DROP TABLE IF EXISTS `forums`;

CREATE TABLE `forums` (
  `f_id` int(10) unsigned NOT NULL auto_increment,
  `f_name` varchar(45) NOT NULL default '',
  `f_area` int(10) unsigned NOT NULL default '0',
  `f_showname` varchar(45) NOT NULL default '',
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Table structure for table `genrep` */

DROP TABLE IF EXISTS `genrep`;

CREATE TABLE `genrep` (
  `g_id` int(10) unsigned NOT NULL auto_increment,
  `g_worldid` int(10) unsigned NOT NULL default '0',
  `g_stationid` int(10) unsigned NOT NULL default '0',
  `g_charid` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`g_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `guides` */

DROP TABLE IF EXISTS `guides`;

CREATE TABLE `guides` (
  `g_id` int(10) unsigned NOT NULL auto_increment,
  `g_type` int(10) unsigned NOT NULL default '0',
  `g_title` varchar(45) NOT NULL default '',
  `g_language` int(2) default NULL,
  `g_content` text NOT NULL,
  `g_chapter` int(1) default '0',
  `g_part` int(1) default '0',
  PRIMARY KEY  (`g_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Table structure for table `inventory` */

DROP TABLE IF EXISTS `inventory`;

CREATE TABLE `inventory` (
  `inv_id` int(10) unsigned NOT NULL auto_increment,
  `inv_charid` int(10) unsigned NOT NULL default '0',
  `inv_loc` int(10) unsigned NOT NULL default '0',
  `inv_x` int(10) unsigned NOT NULL default '0',
  `inv_y` int(10) unsigned NOT NULL default '0',
  `inv_itemid` int(10) unsigned NOT NULL default '0',
  `inv_flag` int(10) unsigned NOT NULL default '0',
  `inv_qty` int(10) unsigned NOT NULL default '0',
  `inv_sqty` int(10) unsigned NOT NULL default '0',
  `inv_cdur` int(10) unsigned NOT NULL default '0',
  `inv_dmg` int(10) unsigned NOT NULL default '0',
  `inv_frq` int(10) unsigned NOT NULL default '0',
  `inv_hnd` int(10) unsigned NOT NULL default '0',
  `inv_rng` int(10) unsigned NOT NULL default '0',
  `inv_mdur` int(10) unsigned NOT NULL default '0',
  `inv_slots` int(10) unsigned NOT NULL default '0',
  `inv_slt1` int(10) unsigned NOT NULL default '0',
  `inv_slt2` int(10) unsigned NOT NULL default '0',
  `inv_slt3` int(10) unsigned NOT NULL default '0',
  `inv_slt4` int(10) unsigned NOT NULL default '0',
  `inv_slt5` int(10) unsigned NOT NULL default '0',
  `inv_atype` int(10) unsigned NOT NULL default '0',
  `inv_contain` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`inv_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

/*Table structure for table `moneytransactions` */

DROP TABLE IF EXISTS `moneytransactions`;

CREATE TABLE `moneytransactions` (
  `mt_id` int(10) NOT NULL auto_increment,
  `mt_clanid` int(10) default '0',
  `mt_amount` int(10) default '0',
  `mt_player` int(10) default '0',
  `mt_date` char(45) collate latin1_general_ci default '2750-01-01 00:00:00',
  `mt_comment` char(255) collate latin1_general_ci default '0',
  PRIMARY KEY  (`mt_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `neochronicle` */

DROP TABLE IF EXISTS `neochronicle`;

CREATE TABLE `neochronicle` (
  `nc_id` int(10) unsigned NOT NULL auto_increment,
  `nc_name` varchar(45) NOT NULL default '',
  `nc_content` text NOT NULL,
  `nc_datetime` varchar(45) NOT NULL default '',
  `nc_lang` int(2) default NULL,
  `nc_approved` int(1) default '0',
  `nc_author` char(45) default '',
  `nc_icon` int(10) default '0',
  PRIMARY KEY  (`nc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Table structure for table `neocron articles` */

DROP TABLE IF EXISTS `neocron articles`;

CREATE TABLE `neocron articles` (
  `na_id` int(10) unsigned NOT NULL auto_increment,
  `na_datetime` varchar(45) NOT NULL default '',
  `na_author` varchar(45) NOT NULL default '0',
  `na_name` varchar(45) NOT NULL default '',
  `na_content` text NOT NULL,
  `na_approval` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`na_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `npc_shop` */

DROP TABLE IF EXISTS `npc_shop`;

CREATE TABLE `npc_shop` (
  `c_npc_id` int(11) default NULL COMMENT 'The NPC WorldID',
  `c_zoneid` int(11) default NULL COMMENT 'The ZoneID in which the NPC is',
  `c_itemid` int(11) default NULL COMMENT 'ItemID for sale',
  `c_itemprice` int(11) default NULL COMMENT 'Price for this item'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `npc_spawns` */

DROP TABLE IF EXISTS `npc_spawns`;

CREATE TABLE `npc_spawns` (
  `npc_id` int(10) unsigned NOT NULL auto_increment,
  `npc_worldid` int(10) unsigned NOT NULL default '0',
  `npc_nameid` int(10) unsigned NOT NULL default '0',
  `npc_typeid` int(10) unsigned NOT NULL default '0',
  `npc_name` varchar(45) NOT NULL default '',
  `npc_location` int(10) unsigned NOT NULL default '0',
  `npc_x` int(10) unsigned NOT NULL default '0',
  `npc_y` int(10) unsigned NOT NULL default '0',
  `npc_z` int(10) unsigned NOT NULL default '0',
  `npc_angle` int(11) NOT NULL default '0',
  `npc_clothing` int(10) unsigned NOT NULL default '0',
  `npc_loot` int(10) unsigned NOT NULL default '0',
  `npc_unknown` int(10) unsigned NOT NULL default '0',
  `npc_trader` int(10) unsigned NOT NULL default '0',
  `npc_customname` varchar(80) default NULL,
  `npc_customscript` varchar(100) default NULL,
  `npc_shop_quality` int(3) default '50' COMMENT 'The quality of items if this npc has items to sell',
  `npc_scripting` int(1) default '1' COMMENT '1: Scripts enabled 0: Scripts disabled',
  PRIMARY KEY  (`npc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9968 DEFAULT CHARSET=latin1;

/*Table structure for table `outposts` */

DROP TABLE IF EXISTS `outposts`;

CREATE TABLE `outposts` (
  `o_id` int(10) unsigned NOT NULL auto_increment,
  `o_outnum` int(10) unsigned NOT NULL default '0',
  `o_security` int(10) unsigned NOT NULL default '0',
  `o_clan` int(10) unsigned NOT NULL default '0',
  `o_gr` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`o_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2213 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `stockx` */

DROP TABLE IF EXISTS `stockx`;

CREATE TABLE `stockx` (
  `st_id` int(10) unsigned NOT NULL auto_increment,
  `st_factid` int(10) unsigned NOT NULL default '0',
  `st_curval` float NOT NULL default '0',
  `st_oldval` float NOT NULL default '0',
  PRIMARY KEY  (`st_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Table structure for table `stockx_depots` */

DROP TABLE IF EXISTS `stockx_depots`;

CREATE TABLE `stockx_depots` (
  `sxd_id` int(10) NOT NULL auto_increment,
  `sxd_playerid` int(10) default '0',
  `sxd_st_id` int(10) default '0',
  `sxd_amount` int(10) default '0',
  `sxd_paid` int(10) default '0',
  PRIMARY KEY  (`sxd_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `support` */

DROP TABLE IF EXISTS `support`;

CREATE TABLE `support` (
  `su_id` int(10) NOT NULL auto_increment,
  `su_player` int(10) default '0',
  `su_datetime` varchar(45) collate latin1_general_ci default '',
  `su_supporterid` int(10) default '0',
  `su_desc` char(255) collate latin1_general_ci default '',
  `su_type` int(1) default '0',
  `su_worldid` int(10) default '0',
  `su_inwork` int(1) default '0',
  `su_finished` int(1) default '0',
  PRIMARY KEY  (`su_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/*Table structure for table `vehicles` */

DROP TABLE IF EXISTS `vehicles`;

CREATE TABLE `vehicles` (
  `v_id` int(10) unsigned NOT NULL auto_increment,
  `v_owner` int(10) unsigned NOT NULL default '0',
  `v_type` int(10) unsigned NOT NULL default '0',
  `v_condition` int(10) unsigned NOT NULL default '0',
  `v_status` int(10) unsigned NOT NULL default '0',
  `v_world` int(10) default '0',
  PRIMARY KEY  (`v_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `world_actors` */

DROP TABLE IF EXISTS `world_actors`;

CREATE TABLE `world_actors` (
  `wa_id` int(10) unsigned NOT NULL auto_increment COMMENT 'Unique ID',
  `wa_actor_id` int(10) unsigned default NULL COMMENT 'u32 ID for the worldactor',
  `wa_actor_map` int(10) unsigned default NULL COMMENT 'World/Zone ID',
  `wa_actor_model` int(10) unsigned default NULL COMMENT 'ID of worldactor (pak_models.ini)',
  `wa_actor_type` int(10) unsigned default NULL COMMENT 'Function type of the actor',
  `wa_posX` int(10) unsigned default NULL,
  `wa_posY` int(10) unsigned default NULL,
  `wa_posZ` int(10) unsigned default NULL,
  `wa_rotX` int(10) unsigned default NULL,
  `wa_rotY` int(10) unsigned default NULL,
  `wa_rotZ` int(10) unsigned default NULL,
  `wa_option1` int(10) unsigned default NULL,
  `wa_option2` int(10) unsigned default NULL,
  `wa_option3` int(10) unsigned default NULL,
  PRIMARY KEY  (`wa_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Table structure for table `worlds` */

DROP TABLE IF EXISTS `worlds`;

CREATE TABLE `worlds` (
  `wr_id` int(10) NOT NULL default '0',
  `wr_group` int(10) default '0',
  PRIMARY KEY  (`wr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

/* Initial Data required */

/*Data for the table `forums` */

insert  into `forums`(`f_id`,`f_name`,`f_area`,`f_showname`) values (1,'bbsnctradeweap',1,'nc.trading.weapons/armor'),(2,'bbsnctraderare',1,'nc.trading.rareparts'),(3,'bbsnctradeimp',1,'nc.trading.implants/boneenforcements'),(4,'bbsnctradepsi',1,'nc.trading.psi equipment'),(5,'bbsnctradeblue',1,'nc.trading.blueprints'),(6,'bbsnctradeitem',1,'nc.trading.itemparts/raw materials'),(7,'bbsnctradedrug',1,'nc.trading.drugs'),(8,'bbsneocronmarket',1,'nc.trading.miscellaneous'),(9,'bbsncrunnerano',2,'nc.runner.anouncements'),(10,'bbsncrunnerserv',2,'nc.runner.services'),(11,'bbsncrunnereven',2,'nc.runner.events'),(12,'bbsncrunnerauct',2,'nc.runner.auctions'),(13,'bbsncrunnerclan',2,'nc.runner.clan recruitment'),(14,'bbsncrunnerfind',2,'nc.runner.find team'),(15,'bbsncrunnerhelp',2,'nc.runner.runner2runnerhelp'),(16,'bbsneocrongeneral',3,'nc.talk.general'),(17,'bbsnctalkpolitics',3,'nc.talk.political discussions'),(18,'bbfgeneral',11,'private.faction.general'),(19,'bbcgeneral',12,'private.clan.general');

/*Data for the table `npc_spawns` */

insert  into `npc_spawns`(`npc_id`,`npc_worldid`,`npc_nameid`,`npc_typeid`,`npc_name`,`npc_location`,`npc_x`,`npc_y`,`npc_z`,`npc_angle`,`npc_clothing`,`npc_loot`,`npc_unknown`,`npc_trader`,`npc_customname`,`npc_customscript`,`npc_shop_quality`,`npc_scripting`) values (9942,1020,385,61093,'WSK',1,33808,31332,32512,30,6612,0,8814,0,'Zippy the Trader','scripts/lua/zippy.lua',50,1),(9943,1020,388,17634,'WSK',3,30063,34111,33136,90,6616,0,14035,0,'Event Info',NULL,50,1),(9944,1018,387,32772,'WSK',101,31938,32165,32512,130,6616,0,16675,0,'Event Info',NULL,50,1),(9945,1019,215,50585,'WSK',101,34209,33864,32512,359,197,0,19499,195,NULL,NULL,50,1),(9946,1020,385,13542,'WSK',101,33261,33113,32672,2,4342,0,17892,0,'VotR Paperboy',NULL,50,1),(9947,1019,389,10890,'WSK',401,31105,32463,31936,92,6613,0,14572,0,'Event Info',NULL,50,1),(9948,1020,1629,26858,'WSK',401,31265,30718,31952,177,2827,0,12567,0,NULL,NULL,50,1),(9949,256,151,31996,'WSK',2046,32168,36946,33946,30,9888,0,738,1,NULL,NULL,50,1),(9950,261,143,58099,'WSK',2046,34016,36182,33970,30,22655,0,2306,200,NULL,NULL,50,1),(9951,963,216,356,'WSK',2046,32703,34945,33818,25,4191,0,3154,196,NULL,NULL,50,1),(9952,976,2818,15528,'WSK',2071,23436,21380,35220,185,7214,0,9785,0,NULL,NULL,50,1),(9953,971,386,5040,'WSK',2181,38000,24127,33854,264,6622,0,2590,0,NULL,NULL,50,1),(9954,1020,836,43282,'MBOTFLY',2181,43068,26020,34020,0,31788,0,405,0,NULL,NULL,50,1),(9955,988,836,41913,'MBOTFLY',2181,41537,28260,33860,0,50146,0,380,0,NULL,NULL,50,1),(9956,1006,800,15709,'MBOT',2181,42047,28256,33786,0,14348,0,220,0,NULL,NULL,50,1),(9957,1005,800,28598,'MBOT',2181,44419,23412,33445,0,8332,0,585,0,NULL,NULL,50,1),(9958,1014,672,28153,'DOGBOT',2181,38041,29414,34088,0,21948,0,221,0,NULL,NULL,50,1),(9959,984,677,32746,'WBADGUY',2181,37985,31043,33939,0,21616,0,222,0,NULL,NULL,50,1),(9960,973,606,26878,'MUTANTB',2181,26220,27158,34106,0,20679,0,490,0,NULL,NULL,50,1),(9961,975,800,11783,'MBOT',2181,31285,23969,33970,0,722,0,38,0,NULL,NULL,50,1),(9962,981,640,61001,'FLYMUT',2181,26672,26657,34281,0,20684,0,1510,0,NULL,NULL,50,1),(9963,985,610,1100,'MGMUT',2181,28040,26301,34083,0,21559,0,628,0,NULL,NULL,50,1),(9964,986,640,1159,'FLYMUT',2181,27424,27264,34328,0,21560,0,1503,0,NULL,NULL,50,1),(9965,987,626,53397,'MUTANTB',2181,26386,27672,34135,0,20680,0,407,0,NULL,NULL,50,1),(9966,999,602,19865,'MUTANTB',2181,26771,26119,34228,0,21559,0,271,0,NULL,NULL,50,1),(9967,1003,730,39449,'BROBOT',2181,25425,32173,34055,0,20939,0,4285,0,NULL,NULL,50,1);

/*Data for the table `outposts` */

insert  into `outposts`(`o_id`,`o_outnum`,`o_security`,`o_clan`,`o_gr`) values (1,2006,0,0,0),(2,2028,0,0,0),(3,2031,0,0,0),(4,2047,0,0,0),(5,2049,0,0,0),(6,2052,9,3,0),(7,2066,0,0,0),(8,2067,0,0,0),(9,2069,0,0,0),(10,2071,0,0,0),(11,2073,0,0,0),(12,2090,0,0,0),(13,2105,0,0,0),(14,2111,0,0,0),(15,2112,0,0,0),(16,2128,0,0,0),(17,2132,0,0,0),(18,2143,0,0,0),(19,2147,0,0,0),(20,2149,0,0,0),(21,2151,0,0,0),(22,2153,0,0,0),(23,2155,0,0,0),(24,2156,0,0,0),(25,2164,0,0,0),(26,2165,0,0,0),(27,2167,0,0,0),(28,2168,0,0,0),(29,2171,0,0,0),(30,2175,0,0,0),(31,2189,0,0,0),(32,2194,0,0,0),(33,2204,0,0,0),(34,2205,0,0,0),(35,2207,0,0,0),(36,2212,0,0,0);

/*Data for the table `stockx` */

insert  into `stockx`(`st_id`,`st_factid`,`st_curval`,`st_oldval`) values (1,9,1227,1227),(2,2,2499,2400),(3,6,1269,1269),(4,10,1387,1387),(5,8,676,676),(6,14,783,783),(7,15,591,591),(8,3,1779,1779),(9,5,879,879),(10,11,1581,2000),(11,4,1544,1544);


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
